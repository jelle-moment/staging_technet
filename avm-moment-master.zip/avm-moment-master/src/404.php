<?php get_header(); ?>

  <body id="bodyProductenPage">



		
		
		<div id="contact_header_image" class="homepageCarousel" style="background-image: url(<?php echo get_site_url(); ?>/wp-content/uploads/2020/11/Service-header.jpg);" );="">
      <div id="contact_titel" class="carousel-tekst">
        <h2>Oeps.. Sorry!</h2>
      </div>
    </div>
		
		
		
		
		<div class="widthContainer">
      <article id="contact_tekst" class="categorieBeschrijving">

				<div>
<h2>We hebben ons best gedaan, maar het lijkt erop dat deze pagina niet (meer) bestaat of misschien verhuisd is.</h2>

<h3>Je kunt natuurlijk altijd even naar de <a href="<?php echo get_site_url(); ?>">homepagina</a> gaan of de zoekfunctie gebruiken. Kom je er echt niet uit? Neem dan even contact met ons op!</h3>

</div>

        <ul>
          <li>Technex BV</li>
          <li>Industrieweg 35</li>
          <li>1521 NE Wormerveer</li>
          <li>Nederland</li>
          <li><a href="tel:+31-075-647-4567">075 647 4567</a></li>
          <li><a href="mailto:info@technex.nl">info@technex.nl</a></li>
        </ul>
      </article>
    </div>

   
<?php get_footer(); ?>
