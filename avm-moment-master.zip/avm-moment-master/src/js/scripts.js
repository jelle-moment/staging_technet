(function( root, $, undefined ) {
	"use strict";

	$(function () {
		// DOM ready, take it away
	});

} ( this, jQuery ));