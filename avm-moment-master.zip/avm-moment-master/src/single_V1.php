<?php get_header(); ?>

<?php
$permalink_contact = get_permalink( 224 ); // var naar contactpagina
?>

	<body style="background-image: url(https://tne001.avm-moment.nl/wp-content/uploads/2020/11/Lijnen75.png);">
    <div class="navbar"></div>
    <div id="product_header_image" class="homepageCarousel" style="background-image: url(<?php echo get_the_post_thumbnail_url(); ?>);">
      <div id="product_titel" class="carousel-tekst">
        <h2><?php if ( the_title() ) : the_title(); endif; ?></h2>
        <ul>
    				<?		// Check rows exists.
if( have_rows('productspecificaties-header') ):
    while( have_rows('productspecificaties-header') ) : the_row();
				
        // Load sub field value.
        $titel_product = get_sub_field('titel-product');
				$waarde = get_sub_field('waarde');

				  echo '<li>';
          echo '<h3>' .  $titel_product . '</h3>';
          echo '<p>' . $waarde . '</p>';
        echo '</li>';

    // End loop.
    endwhile;

// No value.
else :
    // Do something...
endif;?>
        </ul>
      </div>
    </div>

    <div class="positie_rechts">
    <div id="detailpage_productbeschrijving" class="productenContainer">
      <div class="widthContainer">
      <h2>Product beschrijving</h2>
      <article>
        <h3>The System Solution for Efficient Characterization of Polymers</h3>
        <p>
          Bij thermische analyse wordt gekeken naar de fysische veranderingen
           die het gevolg zijn van het aanleggen van een gecontroleerde
           temperatuur en gasatmosfeer. Onder thermische analyse vallen ook
           de warmtetransporteigenschappen zoals thermische conductiviteit en
           diffusiviteit.
        </p>

        <h3 class="beschrijvingHide">The New All-Inclusive Product Package for DSC Measurements</h3>
        <p class="beschrijvingHide">Easy-to-use, robust, precise, optimized for everyday use – these are
          the features of the innovative DSC 214 Polyma. The unique design of
          this instrument encompasses everything needed for successful DSC
          investigations – regardless of whether the user is a beginner or an
          experienced professional. Above all, it is the two new software
          developments that are setting new standards: AutoEvaluation and
          Identify. These have the potential to revolutionize DSC analysis.
          <ul>
            <li>New all-inclusive 360° product package for the characterization of polymers</li>
            <br>
            <li>Easier sample preparation than ever before</li>
            <br>
            <li>Automated measurement and evaluation</li>
          </ul>
        </p>

        <div class="Afbeelding_tekst_container beschrijvingHide">
          <div id="product_img_1" class="product_img_container"></div>
          <h3>AutoEvaluation</h3>
          <p>
            Along with fast heating and cooling rates – which also allow for
            isothermal crystallization experiments – this is expressed
            particularly by the Indium Response Ratio, which is the achievable
            height-to-width-ratio of the melting peak of indium.
          </p>
        </div>

        <h3 class="beschrijvingHide">The First Classic Heat-Flux DSC for Fast Cooling</h3>
        <p class="beschrijvingHide">
          Integrated in the DSC 214 Polyma is an oval furnace with a very
          low thermal mass (Arena® furnace), which allows for heating and
          cooling rates of up to 500 K/min – values previously unachievable
          with heat-flux DSCs. Temperature profiles can now be realized which
          are far closer to real processing conditions.
        </p>
        <p class="beschrijvingHide">
          By combining a very low thermal mass furnace (Arena®) with a robust,
           sensitive sensor (ring-shaped sensor) and optimized crucibles
           (Concavus®), the DSC 214 Polyma achieves impressive performance data.
        </p>
        <p class="beschrijvingHide">
          Along with fast heating and cooling rates – which also allow for
          isothermal crystallization experiments – this is expressed
          particularly by the Indium Response Ratio, which is the achievable
          height-to-width-ratio of the melting peak of indium.
        </p>
        <div id="product_img_2" class="product_img_container beschrijvingHide"></div>
        <q class="beschrijvingHide">
          "For the first time, users now have access to expert applications
          knowledge in the form of an intelligent software algorithm."
        </q>
        <h3 class="beschrijvingHide">AutoEvaluation</h3>
        <p class="beschrijvingHide">
          AutoEvaluation is a completely novel software development allowing
          for the evaluation – automatically or at the push of a button – of
          unknown curves for thermoplastic polymers, rubbers and resins.
          AutoEvaluation analyzes DSC curves by first recognizing any key
          effects such as glass transitions or melting peaks, and then properly
           interpreting side effects such as recrystallization effects in
           logical steps. For the first time, users now have access to expert
           applications knowledge in the form of an intelligent software algorithm.
        </p>
        <h3 class="beschrijvingHide">Identify</h3>
        <p class="beschrijvingHide">
          Identify is a unique tool for automatic identification and
          interpretation of curves with only a single click. This part of
          the software is designed for material identification and quality
          assurance. The analyzed properties of the DSC curve for a given
          material being investigated are compared with the integrated database,
           allowing for the automatic identification of plastic types. Such a
           database comparison is unique in the area of DSC technology. The
           Identify database contains a NETZSCH library for typical polymers and
           can also be extended by adding the user’s own materials. User-specific
            quality criteria can additionally be applied in order to define
            categories. For the first time, individual batches can be objectively
             compared with one another – an ability which is particularly relevant
             in the fields of quality assurance and failure analysis.
        </p>
        <a href="#" id="LeesMeerButton">Lees meer</a>

      </article>
      </div><!-- einde widthContainer -->
    </div>
    <!-- EINDE detailpage_productbeschrijving --------------------------------------------->

	<!-- CONTACT ENH DOWNLOAD -->
  <div class="naar_rechts">
    <div class="artikel_buttons">
      <a href="<? echo $permalink_contact ?>">Contact</a>
      <? if( get_field('datasheet') ):?> <a href="<? the_field('datasheet'); ?>" target="_blank">Datasheet</a> <? endif; ?>
			<? if( get_field('brochure') ):?> <a href="<? the_field('brochure'); ?>" target="_blank">Brochure</a> <? endif; ?>
    </div>
		
		
		
		

    <div class="product_partner_container">
      <h2>Partner</h2>
      <img src="../../assets/images/netzsch.png" alt="" width="300px">
    </div>

    <aside class="product_specificaties">
      <ul>
        <li>
          <h2>Product specificaties</h2>
        </li>
				
		<?		// Check rows exists.
if( have_rows('titelblok-product') ):
    while( have_rows('titelblok-product') ) : the_row();
				
        // Load sub field value.
        $titel_product = get_sub_field('titel-product');
				$waarde = get_sub_field('waarde');

				echo '<li>';
          echo '<h3>' . $titel_product . '</h3>';
          echo '<p>' . $waarde . '</p>';
        echo '</li>';

    // End loop.
    endwhile;

// No value.
else :
    // Do something...
endif;?>
      </ul>
    </aside>
  </div><!-- naar_rechts -->

	<!-- VIDEO -->
	<? if( get_field('youtube_video_link') ):?>
		<iframe width="420" height="315"
		 src="https://www.youtube.com/embed/<? the_field('youtube_video_link'); ?>">
  </iframe>
		<? endif; ?>


  </div><!-- positie_rechts -->

    <!-- EINDE successtoriesContainer ----------------------------------------->

  <script type="text/javascript">
  document.getElementById('LeesMeerButton').addEventListener('click', function(e){
    e.preventDefault(); // prevent a tag default

    var buttonText = LeesMeerButton.innerHTML; // vervang button tekst nadat aangeklikt is
    buttonText = buttonText.replace("Lees meer", "Minder tekst");
    LeesMeerButton.innerHTML = buttonText;

    // show/dontShow alle tekst van de beschrijving
    var x = document.getElementsByClassName("beschrijvingHide");
    for (var i=0;i<x.length;i+=1){
      if (x[i].style.display === "block") {
        x[i].style.display = "none";
      } else {
        x[i].style.display = "block";
        }
      }
    });//addEventListener


  </script>

  </body>

<?php get_footer(); ?>
