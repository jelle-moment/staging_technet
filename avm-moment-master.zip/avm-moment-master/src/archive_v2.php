<?php get_header(); ?>

	<body id="bodyProductenPage">

    <div class="navbar"></div>
	
<?php 
if (isset($_GET['id'])) {
    $post_id = sanitize_text_field( $_GET['id'] );
};

	cat_loop_categorie('productcategorie', null, 1, $post_id); 
	?>
	
    <div id="productenblok" class="productenContainer" style="background-image: url(https://tne001.avm-moment.nl/wp-content/uploads/2020/11/Lijnen75.png);");>
      <h2>Alle producten</h2>
      <div class="widthContainer">
      
	<?php 
		if (is_category('life-science')) : $cat='life-science';
		elseif (is_category('materiaal-beproeving')) : $cat='materiaal-beproeving';
		elseif (is_category('nano-micro-technologie')) : $cat='nano-micro-technologie';
		elseif (is_category('service')) : $cat='service';
		elseif (is_category('spuitgietoptimalisatie')) : $cat='spuitgietoptimalisatie';
		elseif (is_category('thermische-analyse')) : $cat='thermische-analyse';
		endif;
	
		cat_loop_producten('producten', $cat, 60, 'title', 'DESC'); 
		?>
				
      </div><!-- einde widthContainer -->
    </div>
 
    <div class="blogCarouselContainer">blog carousel</div>

  </body>

<?php get_footer(); ?>
