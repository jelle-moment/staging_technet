			<!-- footer -->

			<footer>
      <div class="bigFooterContainer">
        <div class="widthContainer">
          <div class="footerContainerLeft">

              <div class="footerCol">
                <h2>Contact</h2>
                <a>Industrieweg 35</a>
                <a>1521 NE Wormerveer</a>
                <a>Nederland</a>
                <a href="mailto:info@technex.nl">info@technex.nl</a>
                <a href="tel:0031756474567">+31 (0)75 647 45 67</a>	
              </div>

              <div class="footerCol">
                <h2>Handige links</h2>
                <a href="https://tne001.avm-moment.nl/producten">Producten</a>							
								 <a href="<? echo get_permalink( 795 ); ?>">Service aanvraag</a>
                <!-- <a href="<?php // echo get_site_url(); ?>/leveranciers/">Leveranciers</a> -->
                <a href="<? echo get_permalink( 1082 ); ?>">Service Enquete</a>
                <a href="<? echo get_permalink( 224 ); ?>">Contact</a>
              </div>

              <div class="footerCol">
                <h2>Helpful links</h2>
								<a href="<? echo get_permalink( 633 ); ?>">Over ons</a>
                <a href="<?php echo get_site_url(); ?>/nieuws/">Nieuws</a>
                <!-- <a href="<?php // echo get_site_url(); ?>/evennementen/">Evenementen</a> -->
                <!-- <a href="<?php // echo get_site_url(); ?>/blogs/">Blogs</a> -->
                <!-- <a href="<?php // echo get_site_url(); ?>/cases/">Cases</a> -->
              </div>

          </div><!-- einde footerContainerLeft -->

          <div class="footerContainerRight">
            <h2>Connect hier met ons</h2>
            <div class="socialmediaIconenContainer">
              <ul>
                <li><a href="https://www.facebook.com/technexbv" target="_blank" title="Bezoek ons op facebook">
                  <svg version="1.1" id="Layer_1" focusable="false" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 448 512" style="enable-background:new 0 0 448 512;" xml:space="preserve">
                  <path class="st0" d="M400,32H48C21.5,32,0,53.5,0,80v352c0,26.5,21.5,48,48,48h137.2V327.7h-63V256h63v-54.6
                	c0-62.2,37-96.5,93.7-96.5c27.1,0,55.5,4.8,55.5,4.8v61h-31.3c-30.8,0-40.4,19.1-40.4,38.7V256h68.8l-11,71.7h-57.8V480H400
                	c26.5,0,48-21.5,48-48V80C448,53.5,426.5,32,400,32z"></path>
                </svg></a></li>
                <li><a href="https://twitter.com/TechnexBV" target="_blank" title="Bezoek ons op Twitter">
                  <svg version="1.1" id="Layer_2" focusable="false" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 448 512" style="enable-background:new 0 0 448 512;" xml:space="preserve">
                  <path class="st0" d="M400,32H48C21.5,32,0,53.5,0,80v352c0,26.5,21.5,48,48,48h352c26.5,0,48-21.5,48-48V80
                  	C448,53.5,426.5,32,400,32z M351.1,190.8c0.2,2.8,0.2,5.7,0.2,8.5c0,86.7-66,186.6-186.6,186.6c-37.2,0-71.7-10.8-100.7-29.4
                  	c5.3,0.6,10.4,0.8,15.8,0.8c30.7,0,58.9-10.4,81.4-28c-28.8-0.6-53-19.5-61.3-45.5c10.1,1.5,19.2,1.5,29.6-1.2
                  	c-30-6.1-52.5-32.5-52.5-64.4v-0.8c8.7,4.9,18.9,7.9,29.6,8.3c-18.3-12.2-29.2-32.7-29.2-54.6c0-12.2,3.2-23.4,8.9-33.1
                  	c32.3,39.8,80.8,65.8,135.2,68.6c-9.3-44.5,24-80.6,64-80.6c18.9,0,35.9,7.9,47.9,20.7c14.8-2.8,29-8.3,41.6-15.8
                  	c-4.9,15.2-15.2,28-28.8,36.1c13.2-1.4,26-5.1,37.8-10.2C375.1,169.9,363.9,181.5,351.1,190.8z"></path>
                  </svg>
                </a></li>
                <li><a href="https://www.linkedin.com/company/technex-b.v." target="_blank" title="Bezoek ons op LinkeIn">
                  <svg version="1.1" id="Layer_3" focusable="false" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 448 512" style="enable-background:new 0 0 448 512;" xml:space="preserve">
                  <path class="st0" d="M416,32H31.9C14.3,32,0,46.5,0,64.3v383.4C0,465.5,14.3,480,31.9,480H416c17.6,0,32-14.5,32-32.3V64.3
                  	C448,46.5,433.6,32,416,32z M135.4,416H69V202.2h66.5V416H135.4z M102.2,173c-21.3,0-38.5-17.3-38.5-38.5S80.9,96,102.2,96
                  	c21.2,0,38.5,17.3,38.5,38.5C140.7,155.8,123.5,173,102.2,173z M384.3,416h-66.4V312c0-24.8-0.5-56.7-34.5-56.7
                  	c-34.6,0-39.9,27-39.9,54.9V416h-66.4V202.2h63.7v29.2h0.9c8.9-16.8,30.6-34.5,62.9-34.5c67.2,0,79.7,44.3,79.7,101.9V416z"></path>
                  </svg>
                </a></li>
              </ul>
            </div>
          </div>

        </div><!-- einde widthContainer -->
      </div><!-- einde bigFooterContainer -->

      <div class="copyrightFooter">
        <small>Copyright Technex <?php echo date("Y"); ?> | <a href="<?php echo esc_url( get_page_link( 330 ) ); ?>">Colofon</a> | <a href="<?php echo esc_url( get_page_link( 332 ) ); ?>">Privacy en cookies</a> | <a href="<?php echo esc_url( get_page_link( 224 ) ); ?>">Contact</a></small>
        <a href="<?php echo get_site_url(); ?>" class="waygroup">Onderdeel van de Way Group</a>
      </div>

    </footer>

			<!-- /footer -->

		</div>
		<!-- /wrapper -->

		<?php wp_footer(); ?>

		<!-- analytics -->
		<script>
		(function(f,i,r,e,s,h,l){i['GoogleAnalyticsObject']=s;f[s]=f[s]||function(){
		(f[s].q=f[s].q||[]).push(arguments)},f[s].l=1*new Date();h=i.createElement(r),
		l=i.getElementsByTagName(r)[0];h.async=1;h.src=e;l.parentNode.insertBefore(h,l)
		})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
		ga('create', 'UA-XXXXXXXX-XX', 'yourdomain.com');
		ga('send', 'pageview');
		</script>

	</body>
</html>
