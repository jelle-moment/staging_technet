<?php ?>
<q class="beschrijvingHide">
<? if( get_field('tekst_quote') ): the_field('tekst_quote'); endif ?>
</q>