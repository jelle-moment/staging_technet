<?php ?>
<div class="Afbeelding_tekst_container beschrijvingHide">
          <div id="product_img_1" class="product_img_container" alt="<? if( get_field('seo_alt') ): the_field('seo_alt'); endif ?>" title="<? if( get_field('seo_title') ): the_field('seo_title'); endif ?>"  style="background-image: url(<? if( get_field('foto_voor_tekstblok') ): the_field('foto_voor_tekstblok'); endif ?>);">
  
  <img src="<? if( get_field('foto_voor_tekstblok') ): the_field('foto_voor_tekstblok'); endif ?>" alt="<? if( get_field('seo_alt') ): the_field('seo_alt'); endif ?>" class="product_image_image">
  
  
  </div>
          <h3><? if( get_field('titel_voor_tekstblok') ):?> <? the_field('titel_voor_tekstblok'); endif ?></h3>
          <p><? if( get_field('tekst_voor_tekstblok') ):?> <? the_field('tekst_voor_tekstblok'); endif ?></p>
</div>